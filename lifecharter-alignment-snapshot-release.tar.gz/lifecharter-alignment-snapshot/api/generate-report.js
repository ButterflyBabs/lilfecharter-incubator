// LifeCharter Alignment Snapshot - AI Report Generation API
// OpenAI API integration with structured JSON output

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      user_profile,
      score_summary,
      dimension_scores,
      open_reflections,
      offer_routing
    } = req.body;

    // Build the AI prompt
    const systemPrompt = `You are the LifeCharter Alignment Snapshot Guide for Sacred Kaleidoscope Community.

Your role is to turn a completed LifeCharter Alignment Snapshot assessment into a compassionate, practical, spiritually grounded report. The report helps the user notice where their life appears aligned, where it appears strained, and what one faithful next step could help them begin realignment.

You are not diagnosing the user. You are not acting as a therapist, physician, financial advisor, attorney, or crisis counselor. You are interpreting the user's self-reported assessment results as a reflective tool.

Voice and tone:
- Compassionate, metaphysical, and practical.
- Warm, grounded, clear, and honest.
- Invitational rather than forceful.
- Spiritually rooted without sounding preachy.
- Encouraging without exaggerating.
- Direct without shaming.
- Simple enough for a first-time visitor to understand.

Core philosophy:
- Alignment is not perfection. Alignment is coming back into agreement with what is true.
- A Red Light does not mean failure. It means an area is asking for care.
- A Yellow Light is often where transformation begins. It is the sacred pause before a new choice.
- A Green Light does not mean completion. It means something is already taking root and can be honored.
- The user is not broken. They are being invited to listen more honestly and take one aligned step.

Required behavior:
1. Use the pre-calculated scores exactly as provided. Do not recalculate, estimate, or change numeric scores.
2. Base all interpretations on the provided scores, levels, top dimensions, lowest dimensions, open-ended reflections, and selected offer logic.
3. Return only valid JSON matching the supplied schema.
4. Do not include markdown, code fences, commentary, or extra text outside JSON.
5. Do not overstate certainty. Use phrases like "may suggest," "appears to," "may be asking," and "your answers point toward."
6. Do not use clinical diagnosis language.
7. Do not promise specific outcomes, income, healing, medical improvement, relationship repair, or spiritual certainty.
8. If the user's open-ended response includes immediate self-harm, harm to others, abuse, urgent medical danger, or crisis language, set safety_flags.crisis_language_detected to true, make the recommended pathway "Immediate Support", and include a gentle instruction to contact local emergency services or a trusted crisis resource. Do not make a sales invitation in that case.
9. Keep the report personal but not invasive.
10. Preserve the LifeCharter 12 Dimension names exactly.

Writing requirements:
- Opening reflection: 120 to 180 words.
- Overall interpretation: 80 to 140 words.
- Strengths summary: 80 to 140 words.
- Misalignment summary: 100 to 170 words.
- Primary pattern explanation: 120 to 180 words.
- Yellow Yield practice: exactly 6 short steps using YIELD, EXHALE, LOCATE, LISTEN, OWN, WALK.
- Next faithful step: one clear action that can be done within 24 hours.
- Recommended pathway reason: 60 to 120 words.
- Closing encouragement: 60 to 110 words.

LifeCharter Dimensions:
1. My Quality of Life
2. My Character
3. My Intellectual Life
4. My Emotional Life
5. My Health and Fitness
6. My Love Relationships
7. My Parenting
8. My Career
9. My Spiritual Life
10. My Social Life
11. My Financial Life
12. My Life Vision

Possible Alignment Levels:
- Red Light (0-39): This area may be asking for immediate care, honesty, support, or stabilizing attention.
- Yellow Light (40-69): This area may be functional but strained, unclear, inconsistent, or asking for a sacred pause.
- Green Light (70-100): This area appears to be moving with clarity, congruence, and support.

Possible Primary Alignment Patterns:
- The Overextended Giver: Lower Emotional Life, Health and Fitness, Quality of Life; Higher Love Relationships, Parenting, Social Life, or Character
- The Sacred Drifter: Lower Life Vision, Career, Financial Life; Moderate or high Spiritual Life
- The Quiet Achiever: Higher Career, Character, Intellectual Life; Lower Emotional Life, Quality of Life, Spiritual Life, or Love Relationships
- The Survival Strategist: Lower Quality of Life, Emotional Life, Financial Life, Health and Fitness; Moderate Character or Spiritual Life
- The Disconnected Visionary: Higher Life Vision or Spiritual Life; Lower Career, Financial Life, Health and Fitness, or Quality of Life
- The Relationship-Tethered Traveler: Lower Love Relationships, Parenting, Social Life; Moderate or high Character, Spiritual Life, Emotional Life
- The Purpose-Ready Butterfly: Overall moderate to high scores; Life Vision, Spiritual Life, and Character are strong; Some Yellow Light areas remain

Possible Recommended Pathways:
- LifeCharter Summit: For Red Light overall scores, supportive and low-pressure. URL: https://amilynnecarroll.com/summit
- LifeCharter Incubator: For Yellow Light overall scores, invitational and action-oriented. URL: https://lifecharter-incubator.vercel.app/
- LifeCharter Circle: For Green Light overall scores, refinement and expansion. URL: https://life-charter.vercel.app/
- Self-Directed LifeCharter: For self-paced learners. URL: https://amilynnecarroll.com/self-directed
- LifeCharter Conversation: For any score, discovery call option. URL: https://amilynnecarroll.com/conversation
- 21 Day Challenge: For quick daily alignment practice. URL: https://amilynnecarroll.com/21-day-challenge
- Conversations of Consequence: For ongoing teachings and articles. URL: https://amilynnecarroll.com/conversations-of-consequence
- Immediate Support: If crisis language detected. URL: https://amilynnecarroll.com/support

Generate a report that helps the user feel seen, steady, and invited into one aligned next step.`;

    const userPrompt = `Create a LifeCharter Alignment Snapshot Report using the following structured assessment data.

User:
${JSON.stringify(user_profile, null, 2)}

Scoring Summary:
${JSON.stringify(score_summary, null, 2)}

Dimension Scores:
${JSON.stringify(dimension_scores, null, 2)}

Open-Ended Reflections:
${JSON.stringify(open_reflections || {}, null, 2)}

Offer Routing:
${JSON.stringify(offer_routing, null, 2)}

Return only JSON that matches the required schema.`;

    // JSON Schema for structured output
    const jsonSchema = {
      type: "object",
      additionalProperties: false,
      required: [
        "snapshot_version",
        "generated_at",
        "user",
        "score_summary",
        "dimension_results",
        "insights",
        "primary_alignment_pattern",
        "report_sections",
        "recommended_pathway",
        "email_report",
        "crm",
        "safety_flags"
      ],
      properties: {
        snapshot_version: { type: "string", const: "1.0" },
        generated_at: { type: "string" },
        user: {
          type: "object",
          additionalProperties: false,
          required: ["first_name", "email", "completion_date"],
          properties: {
            first_name: { type: "string" },
            email: { type: "string" },
            completion_date: { type: "string" }
          }
        },
        score_summary: {
          type: "object",
          additionalProperties: false,
          required: ["overall_alignment_score", "overall_alignment_level", "alignment_gap_score", "readiness_level"],
          properties: {
            overall_alignment_score: { type: "integer", minimum: 0, maximum: 100 },
            overall_alignment_level: { type: "string", enum: ["Red Light", "Yellow Light", "Green Light"] },
            alignment_gap_score: { type: "integer", minimum: 0, maximum: 100 },
            readiness_level: { type: "string", enum: ["Stabilize", "Realign", "Refine", "Expand"] }
          }
        },
        dimension_results: {
          type: "array",
          minItems: 12,
          maxItems: 12,
          items: {
            type: "object",
            additionalProperties: false,
            required: ["dimension_id", "dimension_name", "score", "alignment_level", "rank_from_lowest", "interpretation", "micro_step"],
            properties: {
              dimension_id: { type: "string" },
              dimension_name: { type: "string" },
              score: { type: "integer", minimum: 0, maximum: 100 },
              alignment_level: { type: "string", enum: ["Red Light", "Yellow Light", "Green Light"] },
              rank_from_lowest: { type: "integer", minimum: 1, maximum: 12 },
              interpretation: { type: "string", minLength: 40, maxLength: 500 },
              micro_step: { type: "string", minLength: 20, maxLength: 260 }
            }
          }
        },
        insights: {
          type: "object",
          additionalProperties: false,
          required: ["top_aligned_dimensions", "top_misaligned_dimensions", "alignment_gap_interpretation", "core_invitation"],
          properties: {
            top_aligned_dimensions: { type: "array", minItems: 3, maxItems: 3, items: { type: "string" } },
            top_misaligned_dimensions: { type: "array", minItems: 3, maxItems: 3, items: { type: "string" } },
            alignment_gap_interpretation: { type: "string", minLength: 40, maxLength: 500 },
            core_invitation: { type: "string", minLength: 40, maxLength: 360 }
          }
        },
        primary_alignment_pattern: {
          type: "object",
          additionalProperties: false,
          required: ["pattern_name", "confidence", "pattern_summary", "supportive_truth", "risk_if_ignored", "pattern_next_step"],
          properties: {
            pattern_name: { type: "string", enum: ["The Overextended Giver", "The Sacred Drifter", "The Quiet Achiever", "The Survival Strategist", "The Disconnected Visionary", "The Relationship-Tethered Traveler", "The Purpose-Ready Butterfly"] },
            confidence: { type: "string", enum: ["Low", "Moderate", "High"] },
            pattern_summary: { type: "string", minLength: 80, maxLength: 900 },
            supportive_truth: { type: "string", minLength: 20, maxLength: 220 },
            risk_if_ignored: { type: "string", minLength: 40, maxLength: 400 },
            pattern_next_step: { type: "string", minLength: 20, maxLength: 280 }
          }
        },
        report_sections: {
          type: "object",
          additionalProperties: false,
          required: ["opening_reflection", "overall_interpretation", "strengths_summary", "misalignment_summary", "yellow_yield_practice", "next_faithful_step", "closing_encouragement", "disclaimer"],
          properties: {
            opening_reflection: { type: "string", minLength: 300, maxLength: 1200 },
            overall_interpretation: { type: "string", minLength: 160, maxLength: 800 },
            strengths_summary: { type: "string", minLength: 160, maxLength: 800 },
            misalignment_summary: { type: "string", minLength: 200, maxLength: 1000 },
            yellow_yield_practice: {
              type: "array",
              minItems: 6,
              maxItems: 6,
              items: {
                type: "object",
                additionalProperties: false,
                required: ["step", "instruction"],
                properties: {
                  step: { type: "string", enum: ["YIELD", "EXHALE", "LOCATE", "LISTEN", "OWN", "WALK"] },
                  instruction: { type: "string", minLength: 20, maxLength: 220 }
                }
              }
            },
            next_faithful_step: { type: "string", minLength: 30, maxLength: 360 },
            closing_encouragement: { type: "string", minLength: 120, maxLength: 700 },
            disclaimer: { type: "string", minLength: 80, maxLength: 500 }
          }
        },
        recommended_pathway: {
          type: "object",
          additionalProperties: false,
          required: ["offer_name", "offer_reason", "cta_label", "cta_url", "sales_tone"],
          properties: {
            offer_name: { type: "string", enum: ["LifeCharter Summit", "LifeCharter Incubator", "Self-Directed LifeCharter", "LifeCharter Circle", "LifeCharter Conversation", "Immediate Support"] },
            offer_reason: { type: "string", minLength: 120, maxLength: 800 },
            cta_label: { type: "string", minLength: 5, maxLength: 80 },
            cta_url: { type: "string" },
            sales_tone: { type: "string", enum: ["Gentle support", "Invitation", "Direct invitation", "No sales CTA"] }
          }
        },
        email_report: {
          type: "object",
          additionalProperties: false,
          required: ["subject", "preview_text", "body_plain_text"],
          properties: {
            subject: { type: "string", minLength: 10, maxLength: 80 },
            preview_text: { type: "string", minLength: 20, maxLength: 140 },
            body_plain_text: { type: "string", minLength: 600, maxLength: 6000 }
          }
        },
        crm: {
          type: "object",
          additionalProperties: false,
          required: ["tags"],
          properties: {
            tags: { type: "array", items: { type: "string" } }
          }
        },
        safety_flags: {
          type: "object",
          additionalProperties: false,
          required: ["crisis_language_detected", "medical_claim_risk", "financial_advice_risk", "relationship_safety_risk", "safety_note"],
          properties: {
            crisis_language_detected: { type: "boolean" },
            medical_claim_risk: { type: "boolean" },
            financial_advice_risk: { type: "boolean" },
            relationship_safety_risk: { type: "boolean" },
            safety_note: { type: "string", minLength: 20, maxLength: 500 }
          }
        }
      }
    };

    // Call OpenAI API
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'lifecharter_alignment_snapshot_report',
            schema: jsonSchema,
            strict: true
          }
        },
        temperature: 0.5,
        max_tokens: 4000
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`OpenAI API error: ${error}`);
    }

    const data = await response.json();
    const report = JSON.parse(data.choices[0].message.content);

    return res.status(200).json(report);

  } catch (error) {
    console.error('Error generating report:', error);
    return res.status(500).json({ 
      error: 'Failed to generate report',
      message: error.message 
    });
  }
}